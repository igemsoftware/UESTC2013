//
//  LoginViewController.h
//  成都体质
//
//  Created by Demo on 13-7-26.
//  Copyright (c) 2013年 usetc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <Twitter/Twitter.h>
#import <Social/Social.h>
#import <Accounts/Accounts.h>
@interface LoginViewController : UIViewController
{
    
    SLComposeViewController *slComposerSheet;
}
@end
