//
//  ResultDataView.h
//  Auto Circuit
//
//  Created by igem on 8/5/13.
//  Copyright (c) 2013 usetc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultDataView : UIView
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *rightLab;
@property (nonatomic,strong) UILabel *LeftLab;
@property (nonatomic,strong) UILabel *bottomLab;

@end
