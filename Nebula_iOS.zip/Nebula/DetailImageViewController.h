//
//  DetailImageViewController.h
//  Auto Circuit
//
//  Created by Demo on 13-8-6.
//  Copyright (c) 2013年 usetc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailImageViewController : UIViewController
@property (nonatomic,strong) NSString *infoStr;
@property (nonatomic,assign) BOOL isHand;
@end
