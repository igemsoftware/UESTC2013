//
//  myDefine.h
//  成都体质
//
//  Created by Demo on 13-7-26.
//  Copyright (c) 2013年 usetc. All rights reserved.
//

#ifndef _____myDefine_h
#define _____myDefine_h
#define imageWithPath(name,type) ([UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:name ofType:type]])


#endif
