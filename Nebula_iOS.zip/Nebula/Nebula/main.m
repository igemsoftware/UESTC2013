//
//  main.m
//  Nebula
//
//  Created by 向 文品 on 13-9-7.
//  Copyright (c) 2013年 Demo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RootAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RootAppDelegate class]));
    }
}
