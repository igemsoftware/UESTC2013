//
//  RootAppDelegate.h
//  Nebula
//
//  Created by 向 文品 on 13-9-7.
//  Copyright (c) 2013年 Demo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
