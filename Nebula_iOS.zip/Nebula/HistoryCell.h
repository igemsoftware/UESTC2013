//
//  HistoryCell.h
//  Auto Circuit
//
//  Created by igem on 8/7/13.
//  Copyright (c) 2013 usetc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryCell : UITableViewCell
@property (nonatomic,strong) UILabel *titleLab;
@property (nonatomic,strong) UILabel *bodyLab;
@property (nonatomic,strong) UIImageView *treeImageView;
@end
