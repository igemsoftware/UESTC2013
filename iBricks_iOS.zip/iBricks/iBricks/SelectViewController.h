//
//  SelectViewController.h
//  iBricks
//
//  Created by 向 文品 on 13-8-28.
//  Copyright (c) 2013年 Demo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectViewController : UIViewController
-(IBAction)cellClick:(UIButton *)sender;
-(IBAction)backButtonClick:(id)sender;
@end
