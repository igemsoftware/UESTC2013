//
//  CompentCell.h
//  iBricks
//
//  Created by 向 文品 on 13-8-29.
//  Copyright (c) 2013年 Demo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompentCell : UITableViewCell
-(void)setStarWithMark:(NSString *)str;
@end
