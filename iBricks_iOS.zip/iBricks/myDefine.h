//
//  myDefine.h
//  iBricks
//
//  Created by 向 文品 on 13-8-29.
//  Copyright (c) 2013年 Demo. All rights reserved.
//

#ifndef iBricks_myDefine_h
#define iBricks_myDefine_h


#define LIFEPOWER 5
#define TIME @[@"60",@"55",@"50",@"45"]
#define WEAPON @[@"0.03",@"0.04",@"0.05",@"0.06"]
#endif
