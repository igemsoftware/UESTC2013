//installation of bootstrap
var app = angular.module('app', ['ui.bootstrap']);








